<!DOCTYPE html>
<html>
<head>
	<meta charset='utf-8'/>
	<title>jQuery elevateZoom Demo</title>
	<script src='zoom_plugin/jquery-1.8.3.min.js'></script>
	<script src='zoom_plugin/jquery.elevatezoom.js'></script>
</head>
<body>
<h1>Basic Zoom Example</h1>
<img id="zoom_01" src='zoom_plugin/images/small/image1.png' data-zoom-image="zoom_plugin/images/large/image1.jpg"/>

<br />
see more examples online <a href="http://www.elevateweb.co.uk/image-zoom/examples">http://www.elevateweb.co.uk/image-zoom/examples</a>
<script>
    $('#zoom_01').elevateZoom({
    	scrollZoom : true,
	zoomWindowFadeIn: 500,
	zoomWindowFadeOut: 500,
	zoomWindowHeight:500,
	zoomWindowWidth:500,
	borderSize:0
   }); 
</script>
</body>
</html>